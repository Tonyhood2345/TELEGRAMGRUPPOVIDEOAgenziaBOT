# 🍓 Configurazione DarIA per Raspberry Pi 400

Questa cartella contiene tutte le personalizzazioni, le regole di stile, i prompt di sistema e le skill personalizzate per ricreare l'ambiente dell'assistente AI sul tuo Raspberry Pi 400.

## 📦 Contenuto del Pacchetto:
1. `config/` - Cartella delle configurazioni globali (plugin, configurazioni di sistema).
2. `agents/` - Cartella delle skill personalizzate (Android CLI, guide, database scientifici, ecc.).
3. `setup_raspberry.sh` - Script di installazione automatica dei prerequisiti su Raspberry Pi OS.

## 🛠️ Come installare su Raspberry Pi 400:
1. Apri il terminale del tuo Raspberry Pi 400.
2. Scarica e installa i prerequisiti di sistema eseguendo:
   ```bash
   chmod +x setup_raspberry.sh
   ./setup_raspberry.sh
   ```
3. Copia la cartella `config` dentro la directory `~/.gemini/config`.
4. Copia la cartella `agents` dentro la directory del tuo progetto.
5. Finito! Ora il tuo Raspberry Pi ha le stesse identiche prestazioni e capacità.

✨ Antonio Giancani
