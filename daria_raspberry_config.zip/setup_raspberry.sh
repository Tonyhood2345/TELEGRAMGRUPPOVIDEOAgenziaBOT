#!/bin/bash
echo "=== Installazione prerequisiti per DarIA su Raspberry Pi 400 ==="

# Aggiorna il sistema
sudo apt update && sudo apt upgrade -y

# Installa Python 3, pip e FFmpeg
sudo apt install -y python3 python3-pip python3-venv ffmpeg nodejs npm git curl

# Installa le librerie Python globali richieste
pip3 install --upgrade pip
pip3 install yt-dlp gspread google-auth requests google-api-python-client

echo "=== Installazione completata con successo! ==="
